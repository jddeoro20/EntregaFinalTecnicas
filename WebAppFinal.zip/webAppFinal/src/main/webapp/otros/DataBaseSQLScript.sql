
CREATE DATABASE proyecto;
USE proyecto;

-- Tabla Usuario
CREATE TABLE Usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) NOT NULL UNIQUE,
    contraseña VARCHAR(100) NOT NULL,
    numero BIGINT NOT NULL,
    cedula BIGINT NOT NULL
);

-- Tabla Cuenta
CREATE TABLE Cuenta (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuarioId INT NOT NULL,
    tipo VARCHAR(50) NOT NULL,
    saldo DOUBLE NOT NULL,
    estado VARCHAR(50) NOT NULL,
    FOREIGN KEY (usuarioId) REFERENCES Usuario(id)
);

-- Tabla Transaccion
CREATE TABLE Transaccion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cuentaId INT NOT NULL,
    tipo VARCHAR(50) NOT NULL,
    cantidad DOUBLE NOT NULL,
    fecha DATETIME NOT NULL,
    moneda VARCHAR(50) NOT NULL,
    cantidadPesos DOUBLE NOT NULL,
    tipoCambio DOUBLE NOT NULL,
    FOREIGN KEY (cuentaId) REFERENCES Cuenta(id)
);

-- Tabla PoliticaBanco
CREATE TABLE PoliticaBanco (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descripcion VARCHAR(255) NOT NULL,
    valor DOUBLE NOT NULL
);

-- Tabla Inmueble
CREATE TABLE Inmueble (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(100) NOT NULL,
    ubicacion VARCHAR(255) NOT NULL,
    precio DOUBLE NOT NULL,
    propietario VARCHAR(100) NOT NULL,
    estado VARCHAR(50) NOT NULL
);

-- Tabla Venta
CREATE TABLE Venta (
    id INT AUTO_INCREMENT PRIMARY KEY,
    propiedadId INT NOT NULL,
    comprador VARCHAR(100) NOT NULL,
    fecha DATETIME NOT NULL,
    precio DOUBLE NOT NULL,
    moneda VARCHAR(50) NOT NULL,
    comision DOUBLE NOT NULL,
    impuestos DOUBLE NOT NULL,
    multas DOUBLE NOT NULL,
    FOREIGN KEY (propiedadId) REFERENCES Inmueble(id)
);