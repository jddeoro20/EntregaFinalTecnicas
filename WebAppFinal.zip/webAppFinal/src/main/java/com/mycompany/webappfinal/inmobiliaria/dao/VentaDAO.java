/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.inmobiliaria.dao;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.inmobiliaria.model.Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class VentaDAO {
    private Connection connection;

    public VentaDAO(Connection connection) {
        this.connection = connection;
    }

    public void agregarVenta(Venta venta) throws SQLException {
        String query = "INSERT INTO Ventas (propiedad_id, comprador, fecha, precio, moneda, comision, impuestos, multas) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, venta.getPropiedadId());
            ps.setString(2, venta.getComprador());
            ps.setDate(3, new java.sql.Date(venta.getFecha().getTime()));
            ps.setDouble(4, venta.getPrecio());
            ps.setString(5, venta.getMoneda());
            ps.setDouble(6, venta.getComision());
            ps.setDouble(7, venta.getImpuestos());
            ps.setDouble(8, venta.getMultas());
            ps.executeUpdate();
        }
    }

    public List<Venta> obtenerVentasEntreFechas(Date fechaInicio, Date fechaFin) throws SQLException {
        String query = "SELECT * FROM Ventas WHERE fecha BETWEEN ? AND ?";
        List<Venta> ventas = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setDate(1, new java.sql.Date(fechaInicio.getTime()));
            ps.setDate(2, new java.sql.Date(fechaFin.getTime()));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ventas.add(new Venta(
                        rs.getInt("id"),
                        rs.getInt("propiedad_id"),
                        rs.getString("comprador"),
                        rs.getDate("fecha"),
                        rs.getDouble("precio"),
                        rs.getString("moneda"),
                        rs.getDouble("comision"),
                        rs.getDouble("impuestos"),
                        rs.getDouble("multas")
                    ));
                }
            }
        }
        return ventas;
    }

    public double calcularTotalRecaudadoPorComisiones(Date fechaInicio, Date fechaFin) throws SQLException {
        String query = "SELECT SUM(comision) AS total FROM Ventas WHERE fecha BETWEEN ? AND ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setDate(1, new java.sql.Date(fechaInicio.getTime()));
            ps.setDate(2, new java.sql.Date(fechaFin.getTime()));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("total");
                }
            }
        }
        return 0.0;
    }

    public double calcularTotalRecaudadoPorMultas(Date fechaInicio, Date fechaFin) throws SQLException {
        String query = "SELECT SUM(multas) AS total FROM Ventas WHERE fecha BETWEEN ? AND ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setDate(1, new java.sql.Date(fechaInicio.getTime()));
            ps.setDate(2, new java.sql.Date(fechaFin.getTime()));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("total");
                }
            }
        }
        return 0.0;
    }
}



