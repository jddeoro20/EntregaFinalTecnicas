/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.model;

/**
 *
 * @author Jesus
 * 
 */

import java.util.Objects;

public class Cuenta {
    private int id;
    private int usuarioId;
    private String tipo;
    private double saldo;
    private String estado;

    public Cuenta(int id, int usuarioId, String tipo, double saldo, String estado) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.tipo = tipo;
        this.saldo = saldo;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cuenta cuenta = (Cuenta) o;
        return id == cuenta.id && usuarioId == cuenta.usuarioId && Double.compare(cuenta.saldo, saldo) == 0 && Objects.equals(tipo, cuenta.tipo) && Objects.equals(estado, cuenta.estado);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, usuarioId, tipo, saldo, estado);
    }
}


