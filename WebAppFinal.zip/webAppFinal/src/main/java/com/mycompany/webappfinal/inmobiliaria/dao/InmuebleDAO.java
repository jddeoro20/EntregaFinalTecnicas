/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.inmobiliaria.dao;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.inmobiliaria.model.Inmueble;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class InmuebleDAO {

    private Connection connection;

    public InmuebleDAO(Connection connection) {
        this.connection = connection;
    }

    public void registrarInmueble(Inmueble inmueble) throws SQLException {
        String query = "INSERT INTO Inmuebles (tipo, ubicacion, precio, propietario, estado) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, inmueble.getTipo());
            ps.setString(2, inmueble.getUbicacion());
            ps.setDouble(3, inmueble.getPrecio());
            ps.setString(4, inmueble.getPropietario());
            ps.setString(5, inmueble.getEstado());
            ps.executeUpdate();
        }
    }

    public Inmueble obtenerInmueble(int id) throws SQLException {
        String query = "SELECT * FROM Inmuebles WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Inmueble(
                            rs.getInt("id"),
                            rs.getString("tipo"),
                            rs.getString("ubicacion"),
                            rs.getDouble("precio"),
                            rs.getString("propietario"),
                            rs.getString("estado")
                    );
                }
            }
        }
        return null;
    }

    public void actualizarInmueble(Inmueble inmueble) throws SQLException {
        String query = "UPDATE Inmuebles SET tipo = ?, ubicacion = ?, precio = ?, propietario = ?, estado = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, inmueble.getTipo());
            ps.setString(2, inmueble.getUbicacion());
            ps.setDouble(3, inmueble.getPrecio());
            ps.setString(4, inmueble.getPropietario());
            ps.setString(5, inmueble.getEstado());
            ps.setInt(6, inmueble.getId());
            ps.executeUpdate();
        }
    }

    public void eliminarInmueble(int id) throws SQLException {
        String query = "DELETE FROM Inmuebles WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Inmueble> obtenerTodosLosInmuebles() throws SQLException {
        List<Inmueble> inmuebles = new ArrayList<>();
        String query = "SELECT * FROM Inmuebles";
        try (PreparedStatement ps = connection.prepareStatement(query); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Inmueble inmueble = new Inmueble(
                        rs.getInt("id"),
                        rs.getString("tipo"),
                        rs.getString("ubicacion"),
                        rs.getDouble("precio"),
                        rs.getString("propietario"),
                        rs.getString("estado")
                );
                inmuebles.add(inmueble);
            }
        }
        return inmuebles;
    }

    public void matricularInmueble(int id) throws SQLException {
        String query = "UPDATE Inmuebles SET estado = 'Matriculado' WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public void venderInmueble(int id) throws SQLException {
        String query = "UPDATE Inmuebles SET estado = 'Vendido' WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public void subastarInmueble(int id) throws SQLException {
        String query = "UPDATE Inmuebles SET estado = 'En Subasta' WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public void registrarCompraVenta(int idInmueble, int idCliente, double precioVenta) throws SQLException {
        String query = "INSERT INTO Transacciones (id_inmueble, id_cliente, precio_venta) VALUES (?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, idInmueble);
            ps.setInt(2, idCliente);
            ps.setDouble(3, precioVenta);
            ps.executeUpdate();
        }
    }

    public void transferirPropiedad(int idInmueble, int idNuevoPropietario) throws SQLException {
        String query = "UPDATE Inmuebles SET propietario = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, idNuevoPropietario);
            ps.setInt(2, idInmueble);
            ps.executeUpdate();
        }
    }

    public List<Inmueble> obtenerInventarioPorFamoso(int idFamoso) throws SQLException {
        List<Inmueble> inmuebles = new ArrayList<>();
        String query = "SELECT * FROM Inmuebles WHERE propietario = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, idFamoso);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Inmueble inmueble = new Inmueble(
                            rs.getInt("id"),
                            rs.getString("tipo"),
                            rs.getString("ubicacion"),
                            rs.getDouble("precio"),
                            rs.getString("propietario"),
                            rs.getString("estado")
                    );
                    inmuebles.add(inmueble);
                }
            }
        }
        return inmuebles;
    }

    public double calcularImpuestosVenta(int idInmueble, double precioVenta) throws SQLException {
       
        return precioVenta * 0.05; 
    }

    public void cobrarMulta(int idInmueble, double montoMulta) throws SQLException {

        String query = "UPDATE Inmuebles SET multa = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setDouble(1, montoMulta);
            ps.setInt(2, idInmueble);
            ps.executeUpdate();
        }
    }
}
