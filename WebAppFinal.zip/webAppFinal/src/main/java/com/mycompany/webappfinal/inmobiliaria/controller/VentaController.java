/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.inmobiliaria.controller;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.inmobiliaria.model.Venta;
import com.mycompany.webappfinal.inmobiliaria.service.VentaService;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class VentaController {
    private VentaService ventaService;

    public VentaController(Connection connection) {
        this.ventaService = new VentaService(connection);
    }

    public void agregarVenta(Venta venta) throws SQLException {
        ventaService.agregarVenta(venta);
    }

    public List<Venta> obtenerVentasEntreFechas(Date fechaInicio, Date fechaFin) throws SQLException {
        return ventaService.obtenerVentasEntreFechas(fechaInicio, fechaFin);
    }

    public double calcularTotalRecaudadoPorComisiones(Date fechaInicio, Date fechaFin) throws SQLException {
        return ventaService.calcularTotalRecaudadoPorComisiones(fechaInicio, fechaFin);
    }

    public double calcularTotalRecaudadoPorMultas(Date fechaInicio, Date fechaFin) throws SQLException {
        return ventaService.calcularTotalRecaudadoPorMultas(fechaInicio, fechaFin);
    }
}



