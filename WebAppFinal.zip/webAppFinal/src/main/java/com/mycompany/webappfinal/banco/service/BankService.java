/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.service;

import com.mycompany.webappfinal.banco.dao.CuentaDAO;
import com.mycompany.webappfinal.banco.dao.TransaccionDAO;
import com.mycompany.webappfinal.banco.model.Cuenta;
import com.mycompany.webappfinal.banco.model.Transaccion;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Jesus
 */
public class BankService {

    private CuentaDAO cuentaDAO;
    private TransaccionDAO transaccionDAO;

    private static final Map<String, Double> tipoCambio = new HashMap<>();

    static {
        tipoCambio.put("USD", 4500.0); // Tipo de cambio de ejemplo, actualizar según sea necesario
        tipoCambio.put("EUR", 5000.0);
        tipoCambio.put("PESOS", 1.0);
    }

    public BankService(Connection connection) {
        this.cuentaDAO = new CuentaDAO(connection);
        this.transaccionDAO = new TransaccionDAO(connection);
    }

    public void depositar(int cuentaId, double cantidad, String moneda) throws SQLException {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("El monto del depósito debe ser positivo.");
        }

        Cuenta cuenta = cuentaDAO.obtenerCuenta(cuentaId);
        if (cuenta == null) {
            throw new SQLException("Cuenta no encontrada.");
        }

        double cantidadPesos = convertirAPesos(cantidad, moneda);
        double cargoTransaccion = calcularCargoTransaccion(cantidadPesos);
        double nuevoSaldo = cuenta.getSaldo() + cantidadPesos - cargoTransaccion;

        cuentaDAO.actualizarSaldo(cuentaId, nuevoSaldo);

        Transaccion transaccion = new Transaccion(
                0, cuentaId, "DEPOSITO", cantidad, new Timestamp(System.currentTimeMillis()), moneda, cantidadPesos, tipoCambio.get(moneda)
        );
        transaccionDAO.agregarTransaccion(transaccion);
    }

    public void retirar(int cuentaId, double cantidad, String moneda) throws SQLException {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("El monto del retiro debe ser positivo.");
        }

        Cuenta cuenta = cuentaDAO.obtenerCuenta(cuentaId);
        if (cuenta == null) {
            throw new SQLException("Cuenta no encontrada.");
        }

        double cantidadPesos = convertirAPesos(cantidad, moneda);
        double cargoTransaccion = calcularCargoTransaccion(cantidadPesos);
        double montoTotal = cantidadPesos + cargoTransaccion;

        if (cuenta.getSaldo() < montoTotal) {
            throw new SQLException("Fondos insuficientes.");
        }

        if (cantidadPesos > 20000000) {
            // Generar alarma y pedir validación adicional
            // Ejemplo de validación adicional (implementar la lógica según sea necesario)
            if (!validarTransaccionGrande()) {
                throw new SQLException("Validación adicional fallida.");
            }
        }

        double nuevoSaldo = cuenta.getSaldo() - montoTotal;
        cuentaDAO.actualizarSaldo(cuentaId, nuevoSaldo);

        Transaccion transaccion = new Transaccion(
                0, cuentaId, "RETIRO", cantidad, new Timestamp(System.currentTimeMillis()), moneda, cantidadPesos, tipoCambio.get(moneda)
        );
        transaccionDAO.agregarTransaccion(transaccion);
    }

    public void transferir(int cuentaOrigenId, int cuentaDestinoId, double cantidad, String moneda) throws SQLException {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("El monto de la transferencia debe ser positivo.");
        }

        Cuenta cuentaOrigen = cuentaDAO.obtenerCuenta(cuentaOrigenId);
        Cuenta cuentaDestino = cuentaDAO.obtenerCuenta(cuentaDestinoId);
        if (cuentaOrigen == null || cuentaDestino == null) {
            throw new SQLException("Una o ambas cuentas no fueron encontradas.");
        }

        double cantidadPesos = convertirAPesos(cantidad, moneda);
        double cargoTransaccion = calcularCargoTransaccion(cantidadPesos);
        double montoTotal = cantidadPesos + cargoTransaccion;

        if (cuentaOrigen.getSaldo() < montoTotal) {
            throw new SQLException("Fondos insuficientes en la cuenta de origen.");
        }

        if (cantidadPesos > 20000000) {
            // Generar alarma y pedir validación adicional
            if (!validarTransaccionGrande()) {
                throw new SQLException("Validación adicional fallida.");
            }
        }

        double nuevoSaldoOrigen = cuentaOrigen.getSaldo() - montoTotal;
        double nuevoSaldoDestino = cuentaDestino.getSaldo() + cantidadPesos;

        cuentaDAO.actualizarSaldo(cuentaOrigenId, nuevoSaldoOrigen);
        cuentaDAO.actualizarSaldo(cuentaDestinoId, nuevoSaldoDestino);

        // Registrar transacción de retiro en cuenta de origen
        Transaccion transaccionOrigen = new Transaccion(
                0, cuentaOrigenId, "TRANSFERENCIA_RETIRO", cantidad, new Timestamp(System.currentTimeMillis()), moneda, cantidadPesos, tipoCambio.get(moneda)
        );
        transaccionDAO.agregarTransaccion(transaccionOrigen);

        // Registrar transacción de depósito en cuenta de destino
        Transaccion transaccionDestino = new Transaccion(
                0, cuentaDestinoId, "TRANSFERENCIA_DEPOSITO", cantidad, new Timestamp(System.currentTimeMillis()), moneda, cantidadPesos, tipoCambio.get(moneda)
        );
        transaccionDAO.agregarTransaccion(transaccionDestino);
    }

    private double convertirAPesos(double cantidad, String moneda) {
        return cantidad * tipoCambio.get(moneda);
    }

    private double calcularCargoTransaccion(double cantidadPesos) {
        double cargo = cantidadPesos * 0.01;
        return (cargo < 50000) ? 100 : cargo;
    }

    private boolean validarTransaccionGrande() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el código de seguridad: ");
        String codigoSeguridad = scanner.nextLine();

        // Verificar si el código ingresado es correcto
        if (codigoSeguridad.equals("1234")) {
            return true;
        } else {
            System.out.println("Código de seguridad incorrecto.");
            return false;
        }
    }
}
