/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.service;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.banco.dao.TransaccionDAO;
import com.mycompany.webappfinal.banco.model.Transaccion;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class TransaccionService {
    private TransaccionDAO transaccionDAO;

    public TransaccionService(Connection connection) {
        this.transaccionDAO = new TransaccionDAO(connection);
    }

    public void agregarTransaccion(int cuentaId, String tipo, double cantidad, Date fecha, String moneda, double conversion, double tipoCambio) throws SQLException {
        Transaccion transaccion = new Transaccion(0, cuentaId, tipo, cantidad, new java.sql.Timestamp(fecha.getTime()), moneda, conversion, tipoCambio);
        transaccionDAO.agregarTransaccion(transaccion);
    }

    public List<Transaccion> obtenerTransaccionesPorCuentaYPeriodo(int cuentaId, Date fechaInicioSql, Date fechaFinSql) throws SQLException {
        return transaccionDAO.obtenerTransaccionesPorCuentaYPeriodo(cuentaId, new java.sql.Date(fechaInicioSql.getTime()), new java.sql.Date(fechaFinSql.getTime()));
    }
}



