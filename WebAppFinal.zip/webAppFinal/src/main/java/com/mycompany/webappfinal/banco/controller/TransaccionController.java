/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.controller;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.banco.model.Transaccion;
import com.mycompany.webappfinal.banco.service.TransaccionService;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class TransaccionController {
    private TransaccionService transaccionService;

    public TransaccionController(TransaccionService transaccionService) {
        this.transaccionService = transaccionService;
    }

    public void agregarTransaccion(int cuentaId, String tipo, double cantidad, Date fecha, String moneda, double conversion, double tipoCambio) {
        try {
            transaccionService.agregarTransaccion(cuentaId, tipo, cantidad, fecha, moneda, conversion, tipoCambio);
            System.out.println("Transacción agregada correctamente.");
        } catch (SQLException e) {
            System.err.println("Error al agregar la transacción: " + e.getMessage());
        }
    }

    public List<Transaccion> obtenerTransaccionesPorCuentaYPeriodo(int cuentaId, Date fechaInicio, Date fechaFin) {
        try {
            return transaccionService.obtenerTransaccionesPorCuentaYPeriodo(cuentaId, fechaInicio, fechaFin);
        } catch (SQLException e) {
            System.err.println("Error al obtener las transacciones: " + e.getMessage());
            return null;
        }
    }
}


    