/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.dao;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.banco.model.PoliticaBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PoliticaBancoDAO {
    private Connection connection;

    public PoliticaBancoDAO(Connection connection) {
        this.connection = connection;
    }

    public PoliticaBanco obtenerPoliticas() throws SQLException {
        String query = "SELECT * FROM PoliticasBanco LIMIT 1";
        try (PreparedStatement ps = connection.prepareStatement(query); ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                PoliticaBanco politica = new PoliticaBanco();
                politica.setComision(rs.getDouble("comision"));
                politica.setTipoInteres(rs.getDouble("tipo_interes"));
                politica.setCuotaMembresia(rs.getDouble("cuota_membresia"));
                politica.setCodigoEtica(rs.getString("codigo_etica"));
                return politica;
            }
            return null;
        }
    }

    public void actualizarPoliticas(PoliticaBanco politica) throws SQLException {
        String query = "UPDATE PoliticasBanco SET comision = ?, tipo_interes = ?, cuota_membresia = ?, codigo_etica = ? WHERE id = 1";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setDouble(1, politica.getComision());
            ps.setDouble(2, politica.getTipoInteres());
            ps.setDouble(3, politica.getCuotaMembresia());
            ps.setString(4, politica.getCodigoEtica());
            ps.executeUpdate();
        }
    }
}


