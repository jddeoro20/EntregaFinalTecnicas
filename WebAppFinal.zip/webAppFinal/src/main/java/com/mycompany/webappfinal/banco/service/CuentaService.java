/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.service;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.banco.dao.CuentaDAO;
import com.mycompany.webappfinal.banco.model.Cuenta;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class CuentaService {
    private CuentaDAO cuentaDAO;

    public CuentaService(Connection connection) {
        this.cuentaDAO = new CuentaDAO(connection);
    }

    public void agregarCuenta(Cuenta cuenta) throws SQLException {
        cuentaDAO.agregarCuenta(cuenta);
    }

    public Cuenta obtenerCuenta(int id) throws SQLException {
        return cuentaDAO.obtenerCuenta(id);
    }

    public void actualizarCuenta(Cuenta cuenta) throws SQLException {
        cuentaDAO.actualizarCuenta(cuenta);
    }

    public List<Cuenta> obtenerCuentasPorEstado(String estado) throws SQLException {
        return cuentaDAO.obtenerCuentasPorEstado(estado);
    }
}



