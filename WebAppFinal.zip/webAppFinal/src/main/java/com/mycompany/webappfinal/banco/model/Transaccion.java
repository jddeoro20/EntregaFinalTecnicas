/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.model;

/**
 *
 * @author Jesus
 */
    import java.sql.Timestamp;
    import java.util.Objects;

    public class Transaccion {
        private int id;
        private int cuentaId;
        private String tipo;
        private double cantidad;
        private Timestamp fecha;
        private String moneda;
        private double conversion;
        private double tipoCambio;

        public Transaccion(int id, int cuentaId, String tipo, double cantidad, Timestamp fecha, String moneda, double conversion, double tipoCambio) {
            this.id = id;
            this.cuentaId = cuentaId;
            this.tipo = tipo;
            this.cantidad = cantidad;
            this.fecha = fecha;
            this.moneda = moneda;
            this.conversion = conversion;
            this.tipoCambio = tipoCambio;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getCuentaId() {
            return cuentaId;
        }

        public void setCuentaId(int cuentaId) {
            this.cuentaId = cuentaId;
        }

        public String getTipo() {
            return tipo;
        }

        public void setTipo(String tipo) {
            this.tipo = tipo;
        }

        public double getCantidad() {
            return cantidad;
        }

        public void setCantidad(double cantidad) {
            this.cantidad = cantidad;
        }

        public Timestamp getFecha() {
            return fecha;
        }

        public void setFecha(Timestamp fecha) {
            this.fecha = fecha;
        }

        public String getMoneda() {
            return moneda;
        }

        public void setMoneda(String moneda) {
            this.moneda = moneda;
        }

        public double getConversion() {
            return conversion;
        }

        public void setConversion(double conversion) {
            this.conversion = conversion;
        }

        public double getTipoCambio() {
            return tipoCambio;
        }

        public void setTipoCambio(double tipoCambio) {
            this.tipoCambio = tipoCambio;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Transaccion that = (Transaccion) o;
            return id == that.id && cuentaId == that.cuentaId && Double.compare(that.cantidad, cantidad) == 0 && Double.compare(that.conversion, conversion) == 0 && Double.compare(that.tipoCambio, tipoCambio) == 0 && Objects.equals(tipo, that.tipo) && Objects.equals(fecha, that.fecha) && Objects.equals(moneda, that.moneda);
        }

        @Override
        public int hashCode() {
            return Objects.hash(id, cuentaId, tipo, cantidad, fecha, moneda, conversion, tipoCambio);
        }
    }

