/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.inmobiliaria.controller;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.inmobiliaria.model.Inmueble;
import com.mycompany.webappfinal.inmobiliaria.service.InmobiliariaService;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class InmuebleController {
    private InmobiliariaService inmobiliariaService;

    public InmuebleController(Connection connection) {
        this.inmobiliariaService = new InmobiliariaService(connection);
    }

    public void registrarInmueble(Inmueble inmueble) {
        try {
            inmobiliariaService.registrarInmueble(inmueble);
            System.out.println("Inmueble registrado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al registrar el inmueble: " + e.getMessage());
        }
    }

    public void obtenerInmueble(int id) {
        try {
            Inmueble inmueble = inmobiliariaService.obtenerInmueble(id);
            if (inmueble != null) {
                System.out.println("Inmueble encontrado: " + inmueble);
            } else {
                System.out.println("Inmueble no encontrado.");
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el inmueble: " + e.getMessage());
        }
    }

    public void actualizarInmueble(Inmueble inmueble) {
        try {
            inmobiliariaService.actualizarInmueble(inmueble);
            System.out.println("Inmueble actualizado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al actualizar el inmueble: " + e.getMessage());
        }
    }

    public void eliminarInmueble(int id) {
        try {
            inmobiliariaService.eliminarInmueble(id);
            System.out.println("Inmueble eliminado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar el inmueble: " + e.getMessage());
        }
    }

    public void obtenerTodosLosInmuebles() {
        try {
            List<Inmueble> inmuebles = inmobiliariaService.obtenerTodosLosInmuebles();
            if (!inmuebles.isEmpty()) {
                System.out.println("Lista de inmuebles:");
                for (Inmueble inmueble : inmuebles) {
                    System.out.println(inmueble);
                }
            } else {
                System.out.println("No hay inmuebles registrados.");
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener la lista de inmuebles: " + e.getMessage());
        }
    }
}




