/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.controller;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.banco.model.Cuenta;
import com.mycompany.webappfinal.banco.service.CuentaService;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class CuentaController {
    private CuentaService cuentaService;

    public CuentaController(Connection connection) {
        this.cuentaService = new CuentaService(connection);
    }

    public void agregarCuenta(Cuenta cuenta) throws SQLException {
        cuentaService.agregarCuenta(cuenta);
    }

    public Cuenta obtenerCuenta(int id) throws SQLException {
        return cuentaService.obtenerCuenta(id);
    }

    public void actualizarCuenta(Cuenta cuenta) throws SQLException {
        cuentaService.actualizarCuenta(cuenta);
    }

    public List<Cuenta> obtenerCuentasPorEstado(String estado) throws SQLException {
        return cuentaService.obtenerCuentasPorEstado(estado);
    }
}




