/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.inmobiliaria.model;

/**
 *
 * @author Jesus
 */
import java.util.Date;

public class Venta {
    private int id;
    private int propiedadId;
    private String comprador;
    private Date fecha;
    private double precio;
    private String moneda;
    private double comision;
    private double impuestos;
    private double multas;

    public Venta(int id, int propiedadId, String comprador, Date fecha, double precio, String moneda,
                 double comision, double impuestos, double multas) {
        this.id = id;
        this.propiedadId = propiedadId;
        this.comprador = comprador;
        this.fecha = fecha;
        this.precio = precio;
        this.moneda = moneda;
        this.comision = comision;
        this.impuestos = impuestos;
        this.multas = multas;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPropiedadId() {
        return propiedadId;
    }

    public void setPropiedadId(int propiedadId) {
        this.propiedadId = propiedadId;
    }

    public String getComprador() {
        return comprador;
    }

    public void setComprador(String comprador) {
        this.comprador = comprador;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public double getComision() {
        return comision;
    }

    public void setComision(double comision) {
        this.comision = comision;
    }

    public double getImpuestos() {
        return impuestos;
    }

    public void setImpuestos(double impuestos) {
        this.impuestos = impuestos;
    }

    public double getMultas() {
        return multas;
    }

    public void setMultas(double multas) {
        this.multas = multas;
    }
}


