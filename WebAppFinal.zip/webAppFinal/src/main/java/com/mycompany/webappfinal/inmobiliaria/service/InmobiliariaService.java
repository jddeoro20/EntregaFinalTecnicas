/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.inmobiliaria.service;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.inmobiliaria.dao.InmuebleDAO;
import com.mycompany.webappfinal.inmobiliaria.model.Inmueble;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class InmobiliariaService {

    private InmuebleDAO inmuebleDAO;

    public InmobiliariaService(Connection connection) {
        this.inmuebleDAO = new InmuebleDAO(connection);
    }

    public void registrarInmueble(Inmueble inmueble) throws SQLException {
        inmuebleDAO.registrarInmueble(inmueble);
    }

    public Inmueble obtenerInmueble(int id) throws SQLException {
        return inmuebleDAO.obtenerInmueble(id);
    }

    public void actualizarInmueble(Inmueble inmueble) throws SQLException {
        inmuebleDAO.actualizarInmueble(inmueble);
    }

    public void eliminarInmueble(int id) throws SQLException {
        inmuebleDAO.eliminarInmueble(id);
    }

    public List<Inmueble> obtenerTodosLosInmuebles() throws SQLException {
        return inmuebleDAO.obtenerTodosLosInmuebles();
    }

    public void matricularInmueble(int id) throws SQLException {
        inmuebleDAO.matricularInmueble(id);
    }

    public void venderInmueble(int id) throws SQLException {
        inmuebleDAO.venderInmueble(id);
    }

    public void subastarInmueble(int id) throws SQLException {
        inmuebleDAO.subastarInmueble(id);
    }

    public void registrarCompraVenta(int idInmueble, int idCliente, double precioVenta) throws SQLException {
        inmuebleDAO.registrarCompraVenta(idInmueble, idCliente, precioVenta);
    }

    public void transferirPropiedad(int idInmueble, int idNuevoPropietario) throws SQLException {
        inmuebleDAO.transferirPropiedad(idInmueble, idNuevoPropietario);
    }

    public List<Inmueble> obtenerInventarioPorFamoso(int idFamoso) throws SQLException {
        return inmuebleDAO.obtenerInventarioPorFamoso(idFamoso);
    }

    public double calcularImpuestosVenta(int idInmueble, double precioVenta) throws SQLException {
        return inmuebleDAO.calcularImpuestosVenta(idInmueble, precioVenta);
    }

    public void cobrarMulta(int idInmueble, double montoMulta) throws SQLException {
        inmuebleDAO.cobrarMulta(idInmueble, montoMulta);
    }
}



