/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.model;

/**
 *
 * @author Jesus
 */
import java.util.Objects;

public class Usuario {
    private int id;
    private String nombre1;
    private String nombre2;
    private String apellido1;
    private String apellido2;

    public Usuario(int id, String nombre1, String nombre2, String apellido1, String apellido2) {
        this.id = id;
        this.nombre1 = nombre1;
        this.nombre2 = nombre2;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre1() {
        return nombre1;
    }

    public void setNombre1(String nombre1) {
        this.nombre1 = nombre1;
    }

    public String getNombre2() {
        return nombre2;
    }

    public void setNombre2(String nombre2) {
        this.nombre2 = nombre2;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return id == usuario.id && Objects.equals(nombre1, usuario.nombre1) && Objects.equals(nombre2, usuario.nombre2) && Objects.equals(apellido1, usuario.apellido1) && Objects.equals(apellido2, usuario.apellido2);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre1, nombre2, apellido1, apellido2);
    }
}

