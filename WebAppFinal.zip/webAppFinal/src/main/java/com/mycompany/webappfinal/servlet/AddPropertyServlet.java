/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.webappfinal.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/addProperty")
public class AddPropertyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recibir los datos del formulario
        String tipo = request.getParameter("tipo");
        String ubicacion = request.getParameter("ubicacion");
        String precio = request.getParameter("precio");
        String propietario = request.getParameter("propietario");
        String estado = request.getParameter("estado");

        // Conectar a la base de datos
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Cargar el controlador de la base de datos
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establecer la conexión con la base de datos
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tu_base_de_datos", "tu_usuario", "tu_contraseña");

            // Crear la consulta SQL
            String sql = "INSERT INTO propiedades (tipo, ubicacion, precio, propietario, estado) VALUES (?, ?, ?, ?, ?)";

            // Preparar la consulta
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, tipo);
            pstmt.setString(2, ubicacion);
            pstmt.setString(3, precio);
            pstmt.setString(4, propietario);
            pstmt.setString(5, estado);

            // Ejecutar la consulta
            pstmt.executeUpdate();

            // Redirigir a una página de éxito
            response.sendRedirect("success.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            // Manejo de errores
            response.sendRedirect("error.jsp");
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}



