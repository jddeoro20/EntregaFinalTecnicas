/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.dao;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.banco.model.Transaccion;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class TransaccionDAO {

    private Connection connection;

    public TransaccionDAO(Connection connection) {
        this.connection = connection;
    }

    public void agregarTransaccion(Transaccion transaccion) throws SQLException {
        String query = "INSERT INTO Transacciones (cuenta_id, tipo, cantidad, fecha, moneda, conversion, tipo_cambio) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, transaccion.getCuentaId());
            ps.setString(2, transaccion.getTipo());
            ps.setDouble(3, transaccion.getCantidad());
            ps.setTimestamp(4, transaccion.getFecha());
            ps.setString(5, transaccion.getMoneda());
            ps.setDouble(6, transaccion.getConversion());
            ps.setDouble(7, transaccion.getTipoCambio());
            ps.executeUpdate();
        }
    }

    public List<Transaccion> obtenerTransaccionesPorCuentaYPeriodo(int cuentaId, Date fechaInicio, Date fechaFin) throws SQLException {
        String query = "SELECT * FROM Transacciones WHERE cuenta_id = ? AND fecha BETWEEN ? AND ?";
        List<Transaccion> transacciones = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, cuentaId);

        
            ps.setDate(2, fechaInicio);
            ps.setDate(3, fechaFin);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    transacciones.add(new Transaccion(
                            rs.getInt("id"),
                            rs.getInt("cuenta_id"),
                            rs.getString("tipo"),
                            rs.getDouble("cantidad"),
                            rs.getTimestamp("fecha"),
                            rs.getString("moneda"),
                            rs.getDouble("conversion"),
                            rs.getDouble("tipo_cambio")
                    ));
                }
            }
        }
        return transacciones;
    }
}
