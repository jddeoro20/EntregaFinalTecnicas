/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.dao;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.banco.model.Cuenta;
import com.mycompany.webappfinal.banco.model.Transaccion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import java.util.List;

public class CuentaDAO {
    private Connection connection;
    private TransaccionDAO transaccionDAO;

    public CuentaDAO(Connection connection) {
        this.connection = connection;
        this.transaccionDAO = new TransaccionDAO(connection);
    }

    public void agregarCuenta(Cuenta cuenta) throws SQLException {
        String query = "INSERT INTO Cuentas (tipo, saldo, estado, usuario_id) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, cuenta.getTipo());
            ps.setDouble(2, cuenta.getSaldo());
            ps.setString(3, cuenta.getEstado());
            ps.setInt(4, cuenta.getUsuarioId());
            ps.executeUpdate();
        }
    }

    public Cuenta obtenerCuenta(int id) throws SQLException {
        String query = "SELECT * FROM Cuentas WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Cuenta(
                        rs.getInt("id"),
                        rs.getInt("usuario_id"),
                        rs.getString("tipo"),
                        rs.getDouble("saldo"),
                        rs.getString("estado")
                    );
                }
            }
        }
        return null;
    }

    public void actualizarCuenta(Cuenta cuenta) throws SQLException {
        String query = "UPDATE Cuentas SET tipo = ?, saldo = ?, estado = ?, usuario_id = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, cuenta.getTipo());
            ps.setDouble(2, cuenta.getSaldo());
            ps.setString(3, cuenta.getEstado());
            ps.setInt(4, cuenta.getUsuarioId());
            ps.setInt(5, cuenta.getId());
            ps.executeUpdate();
        }
    }

    public void actualizarSaldo(int cuentaId, double nuevoSaldo) throws SQLException {
        String query = "UPDATE Cuentas SET saldo = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setDouble(1, nuevoSaldo);
            ps.setInt(2, cuentaId);
            ps.executeUpdate();
        }
    }

    public List<Cuenta> obtenerCuentasPorUsuario(int usuarioId) throws SQLException {
        String query = "SELECT * FROM Cuentas WHERE usuario_id = ?";
        List<Cuenta> cuentas = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, usuarioId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    cuentas.add(new Cuenta(
                        rs.getInt("id"),
                        rs.getInt("usuario_id"),
                        rs.getString("tipo"),
                        rs.getDouble("saldo"),
                        rs.getString("estado")
                    ));
                }
            }
        }
        return cuentas;
    }

    public List<Cuenta> obtenerCuentasPorEstado(String estado) throws SQLException {
        String query = "SELECT * FROM Cuentas WHERE estado = ?";
        List<Cuenta> cuentas = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, estado);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    cuentas.add(new Cuenta(
                        rs.getInt("id"),
                        rs.getInt("usuario_id"),
                        rs.getString("tipo"),
                        rs.getDouble("saldo"),
                        rs.getString("estado")
                    ));
                }
            }
        }
        return cuentas;
    }

    public void eliminarCuenta(int id) throws SQLException {
        String query = "DELETE FROM Cuentas WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Transaccion> obtenerTransaccionesPorCuentaYPeriodo(int cuentaId, Date fechaInicio, Date fechaFin) throws SQLException {
        return transaccionDAO.obtenerTransaccionesPorCuentaYPeriodo(cuentaId, fechaInicio, fechaFin);
    }
}





