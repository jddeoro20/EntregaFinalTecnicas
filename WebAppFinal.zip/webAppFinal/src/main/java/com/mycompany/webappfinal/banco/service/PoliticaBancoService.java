/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.service;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.banco.dao.PoliticaBancoDAO;
import com.mycompany.webappfinal.banco.model.PoliticaBanco;
import java.sql.Connection;
import java.sql.SQLException;

public class PoliticaBancoService {
    private PoliticaBancoDAO politicaBancoDAO;

    public PoliticaBancoService(Connection connection) {
        this.politicaBancoDAO = new PoliticaBancoDAO(connection);
    }

    public PoliticaBanco obtenerPoliticas() throws SQLException {
        return politicaBancoDAO.obtenerPoliticas();
    }

    public void actualizarPoliticas(PoliticaBanco politica) throws SQLException {
        politicaBancoDAO.actualizarPoliticas(politica);
    }
}


