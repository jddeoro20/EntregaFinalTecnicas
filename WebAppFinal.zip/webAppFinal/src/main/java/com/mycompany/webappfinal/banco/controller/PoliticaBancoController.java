/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.controller;

/**
 *
 * @author Jesus
 */
import com.mycompany.webappfinal.banco.model.PoliticaBanco;
import com.mycompany.webappfinal.banco.service.PoliticaBancoService;
import java.sql.Connection;
import java.sql.SQLException;

public class PoliticaBancoController {
    private PoliticaBancoService politicaBancoService;

    public PoliticaBancoController(Connection connection) {
        this.politicaBancoService = new PoliticaBancoService(connection);
    }

    public PoliticaBanco obtenerPoliticas() throws SQLException {
        return politicaBancoService.obtenerPoliticas();
    }

    public void actualizarPoliticas(PoliticaBanco politica) throws SQLException {
        politicaBancoService.actualizarPoliticas(politica);
    }
}


