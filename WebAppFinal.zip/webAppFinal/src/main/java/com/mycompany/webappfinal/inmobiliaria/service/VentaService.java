/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.inmobiliaria.service;

/**
 *
 * @author Jesus
 */

import com.mycompany.webappfinal.inmobiliaria.dao.VentaDAO;
import com.mycompany.webappfinal.inmobiliaria.model.Venta;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class VentaService {
    private VentaDAO ventaDAO;

    public VentaService(Connection connection) {
        this.ventaDAO = new VentaDAO(connection);
    }

    public void agregarVenta(Venta venta) throws SQLException {
        ventaDAO.agregarVenta(venta);
    }

    public List<Venta> obtenerVentasEntreFechas(Date fechaInicio, Date fechaFin) throws SQLException {
        return ventaDAO.obtenerVentasEntreFechas(fechaInicio, fechaFin);
    }

    public double calcularTotalRecaudadoPorComisiones(Date fechaInicio, Date fechaFin) throws SQLException {
        return ventaDAO.calcularTotalRecaudadoPorComisiones(fechaInicio, fechaFin);
    }

    public double calcularTotalRecaudadoPorMultas(Date fechaInicio, Date fechaFin) throws SQLException {
        return ventaDAO.calcularTotalRecaudadoPorMultas(fechaInicio, fechaFin);
    }
}



