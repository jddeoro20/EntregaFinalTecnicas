/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.webappfinal.banco.model;

/**
 *
 * @author Jesus
 */
public class PoliticaBanco {
    private double comision;
    private double tipoInteres;
    private double cuotaMembresia;
    private String codigoEtica;

    // Getters y Setters
    public double getComision() {
        return comision;
    }

    public void setComision(double comision) {
        this.comision = comision;
    }

    public double getTipoInteres() {
        return tipoInteres;
    }

    public void setTipoInteres(double tipoInteres) {
        this.tipoInteres = tipoInteres;
    }

    public double getCuotaMembresia() {
        return cuotaMembresia;
    }

    public void setCuotaMembresia(double cuotaMembresia) {
        this.cuotaMembresia = cuotaMembresia;
    }

    public String getCodigoEtica() {
        return codigoEtica;
    }

    public void setCodigoEtica(String codigoEtica) {
        this.codigoEtica = codigoEtica;
    }
}


